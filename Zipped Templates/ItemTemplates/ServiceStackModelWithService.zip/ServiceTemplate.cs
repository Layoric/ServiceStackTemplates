﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using ServiceStack.Common.Web;
using ServiceStack.DataAnnotations;
using ServiceStack.ServiceHost;
using ServiceStack.ServiceInterface;
using $rootnamespace$.DTOs;

namespace $rootnamespace$.Services
{
    /// <summary>
    /// Service
    /// </summary>
    public class $safeitemname$ : Service
    {
        public object Get($fileinputname$Request request)
        {
            throw new NotImplementedException();
        }

        public object Post($fileinputname$Request request)
        {
            throw new NotImplementedException();
        }

        public object Put($fileinputname$Request request)
        {
            throw new NotImplementedException();
        }

        public object Delete($fileinputname$Request request)
        {
            throw new NotImplementedException();
        }

        //public object Any($fileinputname$Request request)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
