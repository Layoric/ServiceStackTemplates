﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using ServiceStack.Common.Web;
using ServiceStack.DataAnnotations;
using ServiceStack.ServiceHost;
using ServiceStack.ServiceInterface;

namespace $rootnamespace$.Models
{
    /// <summary>
    /// Data layer model
    /// </summary>
    public class $safeitemname$
    {
    
    }
}
